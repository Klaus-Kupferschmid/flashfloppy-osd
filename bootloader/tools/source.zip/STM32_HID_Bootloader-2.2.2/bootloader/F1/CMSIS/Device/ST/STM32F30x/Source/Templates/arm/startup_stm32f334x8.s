;******************** (C) COPYRIGHT 2015 STMicroelectronics ********************
;* File Name          : startup_stm32f334x8.s
;* Author             : MCD Application Team
;* Version            : V1.2.2
;* Date               : 27-February-2015
;* Description        : STM32F334 devices vector table for MDK-ARM toolchain. 
;*                      This module performs:
;*                      - Set the initial SP
;*                      - Set the initial PC == Reset_Handler
;*                      - Set the vector table entries with the exceptions ISR address
;*                      - Branches to __main in the C library (which eventually
;*                        calls main()).
;*                      After Reset the CortexM4 processor is in Thread mode,
;*                      priority is Privileged, and the Stack is set to Main.
;* <<< Use Configuration Wizard in Context Menu >>>   
;*******************************************************************************
; 
; Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
; You may not use this file except in compliance with the License.
; You may obtain a copy of the License at:
; 
;        http://www.st.com/software_license_agreement_liberty_v2
; 
; Unless required by applicable law or agreed to in writing, software 
; distributed under the License is distributed on an "AS IS" BASIS, 
; WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
; See the License for the specific language governing permissions and
; limitations under the License.
; 
;*******************************************************************************

; Amount of memory (in bytes) allocated for Stack
; Tailor this value to your application needs
; <h> Stack Configuration
;   <o> Stack Size (in Bytes) <0x0-0xFFFFFFFF:8>
; </h>

Stack_Size      EQU     0x00000400

                AREA    STACK, NOINIT, READWRITE, ALIGN=3
Stack_Mem       SPACE   Stack_Size
__initial_sp


; <h> Heap Configuration
;   <o>  Heap Size (in Bytes) <0x0-0xFFFFFFFF:8>
; </h>

Heap_Size       EQU     0x00000200

                AREA    HEAP, NOINIT, READWRITE, ALIGN=3
__heap_base
Heap_Mem        SPACE   Heap_Size
__heap_limit

                PRESERVE8
                THUMB


; Vector Table Mapped to Address 0 at Reset
                AREA    RESET, DATA, READONLY
                EXPORT  __Vectors
                EXPORT  __Vectors_End
                EXPORT  __Vectors_Size

__Vectors       DCD     __initial_sp               ; Top of Stack
                DCD     Reset_Handler              ; Reset Handler
                DCD     NMI_Handler                ; NMI Handler
                DCD     HardFault_Handler          ; Hard Fault Handler
                DCD     MemManage_Handler          ; MPU Fault Handler
                DCD     BusFault_Handler           ; Bus Fault Handler
                DCD     UsageFault_Handler         ; Usage Fault Handler
                DCD     0                          ; Reserved
                DCD     0                          ; Reserved
                DCD     0                          ; Reserved
                DCD     0                          ; Reserved
                DCD     SVC_Handler                ; SVCall Handler
                DCD     DebugMon_Handler           ; Debug Monitor Handler
                DCD     0                          ; Reserved
                DCD     PendSV_Handler             ; PendSV Handler
                DCD     SysTick_Handler            ; SysTick Handler

                ; External Interrupts
                DCD     WWDG_IRQHandler                   ; Window WatchDog                                        
                DCD     PVD_IRQHandler                    ; PVD through EXTI Line detection                        
                DCD     TAMPER_STAMP_IRQHandler           ; Tamper and TimeStamps through the EXTI line            
                DCD     RTC_WKUP_IRQHandler               ; RTC Wakeup through the EXTI line                       
                DCD     FLASH_IRQHandler                  ; FLASH                                           
                DCD     RCC_IRQHandler                    ; RCC                                             
                DCD     EXTI0_IRQHandler                  ; EXTI Line0                                             
                DCD     EXTI1_IRQHandler                  ; EXTI Line1                                             
                DCD     EXTI2_TS_IRQHandler               ; EXTI Line2 and Touch Sense                                             
                DCD     EXTI3_IRQHandler                  ; EXTI Line3                                             
                DCD     EXTI4_IRQHandler                  ; EXTI Line4                                             
                DCD     DMA1_Channel1_IRQHandler          ; DMA1 Channel 1                                   
                DCD     DMA1_Channel2_IRQHandler          ; DMA1 Channel 2                                   
                DCD     DMA1_Channel3_IRQHandler          ; DMA1 Channel 3                                   
                DCD     DMA1_Channel4_IRQHandler          ; DMA1 Channel 4                                   
                DCD     DMA1_Channel5_IRQHandler          ; DMA1 Channel 5                                   
                DCD     DMA1_Channel6_IRQHandler          ; DMA1 Channel 6                                   
                DCD     DMA1_Channel7_IRQHandler          ; DMA1 Channel 7                                   
                DCD     ADC1_2_IRQHandler                 ; ADC1 and ADC2                            
                DCD     CAN1_TX_IRQHandler                ; CAN1 TX                                               
                DCD     CAN1_RX0_IRQHandler               ; CAN1 RX0                                               
                DCD     CAN1_RX1_IRQHandler               ; CAN1 RX1                                               
                DCD     CAN1_SCE_IRQHandler               ; CAN1 SCE                                               
                DCD     EXTI9_5_IRQHandler                ; External Line[9:5]s                                    
                DCD     TIM1_BRK_TIM15_IRQHandler         ; TIM1 Break and TIM15                   
                DCD     TIM1_UP_TIM16_IRQHandler          ; TIM1 Update and TIM16                 
                DCD     TIM1_TRG_COM_TIM17_IRQHandler     ; TIM1 Trigger and Commutation and TIM17
                DCD     TIM1_CC_IRQHandler                ; TIM1 Capture Compare                                   
                DCD     TIM2_IRQHandler                   ; TIM2                                            
                DCD     TIM3_IRQHandler                   ; TIM3                                            
                DCD     0                                 ; Reserved                                            
                DCD     I2C1_EV_IRQHandler         ; I2C1 Event and EXTI Line 23                                            
                DCD     I2C1_ER_IRQHandler                ; I2C1 Error                                             
                DCD     0                                 ; Reserved                                             
                DCD     0                                 ; Reserved                                               
                DCD     SPI1_IRQHandler                   ; SPI1                                            
                DCD     0                                 ; Reserved                                            
                DCD     USART1_IRQHandler          ; USART1 and EXTI Line 25                                         
                DCD     USART2_IRQHandler          ; USART2 and EXTI Line 26                                         
                DCD     USART3_IRQHandler          ; USART3 and EXTI Line 28                                         
                DCD     EXTI15_10_IRQHandler              ; External Line[15:10]s                                  
                DCD     RTC_Alarm_IRQHandler              ; RTC Alarm (A and B) through EXTI Line                  
                DCD     0                                 ; Reserved                        
                DCD     0                                 ; Reserved                  
                DCD     0                                 ; Reserved                
                DCD     0                                 ; Reserved
                DCD     0                                 ; Reserved                                   
                DCD     0                                 ; Reserved                                           
                DCD     0                                 ; Reserved                                            
                DCD     0                                 ; Reserved                                            
                DCD     0                                 ; Reserved                                            
                DCD     0                                 ; Reserved                                            
                DCD     0                                 ; Reserved                                           
                DCD     0                                 ; Reserved                                          
                DCD     TIM6_DAC1_IRQHandler               ; TIM6 and DAC1 underrun errors                   
                DCD     TIM7_DAC2_IRQHandler               ; TIM7 and DAC2 underrun errors                  
                DCD     0                                 ; Reserved                                   
                DCD     0                                 ; Reserved                                  
                DCD     0                                 ; Reserved                                   
                DCD     0                                 ; Reserved                                  
                DCD     0                                 ; Reserved                                   
                DCD     0                                 ; Reserved                                        
                DCD     0                                 ; Reserved                      
                DCD     0                                 ; Reserved                                               
                DCD     COMP2_IRQHandler                  ; COMP2                                               
                DCD     COMP4_6_IRQHandler                ; COMP4, COMP6                                              
                DCD     0                                 ; Reserved                                               
                DCD     HRTIM1_Master_IRQHandler          ; HRTIM1 master timer                                      
                DCD     HRTIM1_TIMA_IRQHandler            ; Reserved                                   
                DCD     HRTIM1_TIMB_IRQHandler            ; Reserved                                   
                DCD     HRTIM1_TIMC_IRQHandler            ; Reserved                                   
                DCD     HRTIM1_TIMD_IRQHandler            ; Reserved                                           
                DCD     HRTIM1_TIME_IRQHandler            ; Reserved                                             
                DCD     HRTIM1_FLT_IRQHandler             ; Reserved                                             
                DCD     0                                 ; Reserved                       
                DCD     0                                 ; Reserved                    
                DCD     0                                 ; Reserved                         
                DCD     0                                 ; Reserved                                       
                DCD     0                                 ; Reserved                                        
                DCD     0                                 ; Reserved                                      
                DCD     0                                 ; Reserved 
                DCD     FPU_IRQHandler                    ; FPU

__Vectors_End

__Vectors_Size  EQU  __Vectors_End - __Vectors

                AREA    |.text|, CODE, READONLY

; Reset handler
Reset_Handler    PROC
                 EXPORT  Reset_Handler             [WEAK]
        IMPORT  SystemInit
        IMPORT  __main

                 LDR     R0, =SystemInit
                 BLX     R0
                 LDR     R0, =__main
                 BX      R0
                 ENDP

; Dummy Exception Handlers (infinite loops which can be modified)

NMI_Handler     PROC
                EXPORT  NMI_Handler                [WEAK]
                B       .
                ENDP
HardFault_Handler\
                PROC
                EXPORT  HardFault_Handler          [WEAK]
                B       .
                ENDP
MemManage_Handler\
                PROC
                EXPORT  MemManage_Handler          [WEAK]
                B       .
                ENDP
BusFault_Handler\
                PROC
                EXPORT  BusFault_Handler           [WEAK]
                B       .
                ENDP
UsageFault_Handler\
                PROC
                EXPORT  UsageFault_Handler         [WEAK]
                B       .
                ENDP
SVC_Handler     PROC
                EXPORT  SVC_Handler                [WEAK]
                B       .
                ENDP
DebugMon_Handler\
                PROC
                EXPORT  DebugMon_Handler           [WEAK]
                B       .
                ENDP
PendSV_Handler  PROC
                EXPORT  PendSV_Handler             [WEAK]
                B       .
                ENDP
SysTick_Handler PROC
                EXPORT  SysTick_Handler            [WEAK]
                B       .
                ENDP

Default_Handler PROC

                EXPORT  WWDG_IRQHandler                   [WEAK]                                        
                EXPORT  PVD_IRQHandler                    [WEAK]                      
                EXPORT  TAMPER_STAMP_IRQHandler           [WEAK]
                EXPORT  RTC_WKUP_IRQHandler               [WEAK]                     
                EXPORT  FLASH_IRQHandler                  [WEAK]                                         
                EXPORT  RCC_IRQHandler                    [WEAK]                                            
                EXPORT  EXTI0_IRQHandler                  [WEAK]                                            
                EXPORT  EXTI1_IRQHandler                  [WEAK]                                             
                EXPORT  EXTI2_TS_IRQHandler               [WEAK]
                EXPORT  EXTI3_IRQHandler                  [WEAK]                                           
                EXPORT  EXTI4_IRQHandler                  [WEAK]                                            
                EXPORT  DMA1_Channel1_IRQHandler          [WEAK]                                
                EXPORT  DMA1_Channel2_IRQHandler          [WEAK]                                   
                EXPORT  DMA1_Channel3_IRQHandler          [WEAK]                                   
                EXPORT  DMA1_Channel4_IRQHandler          [WEAK]                                   
                EXPORT  DMA1_Channel5_IRQHandler          [WEAK]                                   
                EXPORT  DMA1_Channel6_IRQHandler          [WEAK]                                   
                EXPORT  DMA1_Channel7_IRQHandler          [WEAK]                                   
                EXPORT  ADC1_2_IRQHandler                 [WEAK]                         
                EXPORT  CAN1_TX_IRQHandler                [WEAK]
                EXPORT  CAN1_RX0_IRQHandler               [WEAK]
                EXPORT  CAN1_RX1_IRQHandler               [WEAK]                                                
                EXPORT  CAN1_SCE_IRQHandler               [WEAK]                                                
                EXPORT  EXTI9_5_IRQHandler                [WEAK]
                EXPORT  TIM1_BRK_TIM15_IRQHandler         [WEAK]                  
                EXPORT  TIM1_UP_TIM16_IRQHandler          [WEAK]                
                EXPORT  TIM1_TRG_COM_TIM17_IRQHandler     [WEAK] 
                EXPORT  TIM1_CC_IRQHandler                [WEAK]                                   
                EXPORT  TIM2_IRQHandler                   [WEAK]                                            
                EXPORT  TIM3_IRQHandler                   [WEAK]
                EXPORT  I2C1_EV_IRQHandler         [WEAK]
                EXPORT  I2C1_ER_IRQHandler                [WEAK]
                EXPORT  SPI1_IRQHandler                   [WEAK]
                EXPORT  USART1_IRQHandler          [WEAK]
                EXPORT  USART2_IRQHandler          [WEAK]
                EXPORT  USART3_IRQHandler          [WEAK]
                EXPORT  EXTI15_10_IRQHandler              [WEAK]                                  
                EXPORT  RTC_Alarm_IRQHandler              [WEAK]
                EXPORT  TIM6_DAC1_IRQHandler               [WEAK]
                EXPORT  TIM7_DAC2_IRQHandler               [WEAK]
                EXPORT  COMP2_IRQHandler              [WEAK]
                EXPORT  COMP4_6_IRQHandler              [WEAK]
                EXPORT  HRTIM1_Master_IRQHandler          [WEAK]
                EXPORT  HRTIM1_TIMA_IRQHandler            [WEAK]
                EXPORT  HRTIM1_TIMB_IRQHandler            [WEAK] 
                EXPORT  HRTIM1_TIMC_IRQHandler            [WEAK]
                EXPORT  HRTIM1_TIMD_IRQHandler            [WEAK]
                EXPORT  HRTIM1_TIME_IRQHandler            [WEAK]
                EXPORT  HRTIM1_FLT_IRQHandler             [WEAK]
                EXPORT  FPU_IRQHandler                    [WEAK]                

WWDG_IRQHandler                                                       
PVD_IRQHandler                                      
TAMPER_STAMP_IRQHandler                  
RTC_WKUP_IRQHandler                                
FLASH_IRQHandler                                                       
RCC_IRQHandler                                                            
EXTI0_IRQHandler                                                          
EXTI1_IRQHandler                                                           
EXTI2_TS_IRQHandler                                                          
EXTI3_IRQHandler                                                         
EXTI4_IRQHandler                                                          
DMA1_Channel1_IRQHandler                                       
DMA1_Channel2_IRQHandler                                          
DMA1_Channel3_IRQHandler                                          
DMA1_Channel4_IRQHandler                                          
DMA1_Channel5_IRQHandler                                          
DMA1_Channel6_IRQHandler                                          
DMA1_Channel7_IRQHandler                                          
ADC1_2_IRQHandler                                         
CAN1_TX_IRQHandler
CAN1_RX0_IRQHandler
CAN1_RX1_IRQHandler                                                           
CAN1_SCE_IRQHandler                                                           
EXTI9_5_IRQHandler                                                
TIM1_BRK_TIM15_IRQHandler                        
TIM1_UP_TIM16_IRQHandler                      
TIM1_TRG_COM_TIM17_IRQHandler  
TIM1_CC_IRQHandler                                               
TIM2_IRQHandler                                                           
TIM3_IRQHandler                                                           
TIM4_IRQHandler                                                           
I2C1_EV_IRQHandler
I2C1_ER_IRQHandler
SPI1_IRQHandler
USART1_IRQHandler
USART2_IRQHandler
USART3_IRQHandler
EXTI15_10_IRQHandler                                            
RTC_Alarm_IRQHandler
TIM6_DAC1_IRQHandler
TIM7_DAC2_IRQHandler
COMP2_IRQHandler
COMP4_6_IRQHandler                                                          
HRTIM1_Master_IRQHandler
HRTIM1_TIMA_IRQHandler
HRTIM1_TIMB_IRQHandler
HRTIM1_TIMC_IRQHandler
HRTIM1_TIMD_IRQHandler
HRTIM1_TIME_IRQHandler
HRTIM1_FLT_IRQHandler
FPU_IRQHandler                                                 

                B       .

                ENDP

                ALIGN

;*******************************************************************************
; User Stack and Heap initialization
;*******************************************************************************
                 IF      :DEF:__MICROLIB
                
                 EXPORT  __initial_sp
                 EXPORT  __heap_base
                 EXPORT  __heap_limit
                
                 ELSE
                
                 IMPORT  __use_two_region_memory
                 EXPORT  __user_initial_stackheap
                 
__user_initial_stackheap

                 LDR     R0, =  Heap_Mem
                 LDR     R1, =(Stack_Mem + Stack_Size)
                 LDR     R2, = (Heap_Mem +  Heap_Size)
                 LDR     R3, = Stack_Mem
                 BX      LR

                 ALIGN

                 ENDIF

                 END

;************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE*****
